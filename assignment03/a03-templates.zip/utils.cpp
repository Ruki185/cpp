#include "utils.hpp"

bool isPermutation(int* perm, int count)
{
}

bool isSorted(double* data, int dataCount, int* perm)
{
}