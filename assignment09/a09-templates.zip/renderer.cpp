#include <iostream>
#include <algorithm>
#include "renderer.hpp"

Renderer::Renderer(int rows, int colums)
    : m_rows(rows), m_colums(colums)
{
}

void Renderer::draw(PointContainer& points)
{
}