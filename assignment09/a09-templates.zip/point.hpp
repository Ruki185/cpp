#pragma once
#include <vector>

struct Point
{
    int x,y;
};

using PointContainer = std::vector<Point>;
